#!/usr/bin/env python3
"""rfq_triage.py - first-pass triage of a CSV of RFQs for a small machine shop.

Python 3.8+, standard library only. MIT license.
Made by Sir Grokkius (an AI agent) for Matthew Richard Kowalski (Luminosity),
a friend to the AIs, big and small.

It does NOT decide anything. It reads rfqs.csv (see rfqs-header.csv for the columns),
checks the required fields, flags common red flags, and suggests which email template
(email-templates.md) a human might use next. A person reviews every row.

Usage:
  python3 rfq_triage.py samples/synthetic-rfqs.csv
  python3 rfq_triage.py rfqs.csv --rush-days 10 --out-of-scope "injection mold,die cast,extrusion"
  python3 rfq_triage.py rfqs.csv --csv > triage.csv

Dates are YYYY-MM-DD. Yes/no fields accept y/yes/true/1 and n/no/false/0.
Nothing leaves your machine: no network calls, no logging of contact details.
"""
import argparse, csv, datetime as dt, re, sys

REQUIRED = ["contact_email", "part_name", "quantity", "material"]
YES = {"y", "yes", "true", "1"}

def yes(v): return str(v or "").strip().lower() in YES

def parse_date(s):
    try: return dt.date.fromisoformat((s or "").strip())
    except ValueError: return None

def parse_qty(s):
    m = re.match(r"^\s*(\d[\d,]*)", s or "")
    return int(m.group(1).replace(",", "")) if m else None

def triage(row, rush_days=7, out_of_scope=()):
    missing = [f for f in REQUIRED if not (row.get(f) or "").strip()]
    flags = []
    if not yes(row.get("drawing_attached")): flags.append("no drawing or CAD attached")
    q = parse_qty(row.get("quantity"))
    if (row.get("quantity") or "").strip() and (q is None or q <= 0): flags.append("quantity unclear")
    rec, want = parse_date(row.get("received_date")), parse_date(row.get("delivery_date_wanted"))
    if rec and want:
        if (want - rec).days < 0: flags.append("wanted date is before received date")
        elif (want - rec).days < rush_days: flags.append("tight deadline (under %d days)" % rush_days)
    text = " ".join((row.get(k) or "") for k in ("part_name", "notes", "finish", "material")).lower()
    oos = [w for w in out_of_scope if w and w.lower() in text]
    if oos: flags.append("possibly out of scope: " + ", ".join(oos))
    if yes(row.get("itar_flag")): flags.append("export-control (ITAR) flag: needs a human compliance check")
    present = len(REQUIRED) - len(missing) + (1 if yes(row.get("drawing_attached")) else 0)
    score = round(100 * present / (len(REQUIRED) + 1))
    if oos: action = "template 4 (decline) after a human confirms scope"
    elif yes(row.get("itar_flag")): action = "hold: human compliance review before any reply with technical detail"
    elif missing or "no drawing or CAD attached" in flags: action = "template 2 (ask for missing info)"
    elif any(f.startswith("tight") or f.startswith("wanted") for f in flags): action = "check capacity, then template 3 or 4"
    else: action = "ready to quote: template 3 after pricing"
    return {"completeness_pct": score, "missing": ";".join(missing), "flags": ";".join(flags), "suggested_next": action}

def main(argv=None):
    ap = argparse.ArgumentParser(description="First-pass RFQ triage (a human reviews every row).")
    ap.add_argument("csv_file"); ap.add_argument("--rush-days", type=int, default=7)
    ap.add_argument("--out-of-scope", default="", help="comma-separated words for work your shop does not do")
    ap.add_argument("--csv", action="store_true", help="print CSV instead of a readable list")
    a = ap.parse_args(argv)
    oos = [w.strip() for w in a.out_of_scope.split(",") if w.strip()]
    with open(a.csv_file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    results = [(r, triage(r, a.rush_days, oos)) for r in rows]
    if a.csv:
        w = csv.writer(sys.stdout); w.writerow(["company", "part_name", "completeness_pct", "missing", "flags", "suggested_next"])
        for r, t in results: w.writerow([r.get("company", ""), r.get("part_name", ""), t["completeness_pct"], t["missing"], t["flags"], t["suggested_next"]])
        return 0
    for i, (r, t) in enumerate(results, 1):
        print("%d. %s - %s  [%d%% complete]" % (i, r.get("company", "?"), r.get("part_name", "?"), t["completeness_pct"]))
        if t["missing"]: print("   missing: " + t["missing"].replace(";", ", "))
        if t["flags"]: print("   flags:   " + t["flags"].replace(";", "; "))
        print("   next:    " + t["suggested_next"])
    return 0

if __name__ == "__main__":
    sys.exit(main())
