# Email and message templates for RFQ replies

Seven plain templates for small machine shops. Replace every [PLACEHOLDER]. Drafted by a free AI model (Groq-hosted gpt-oss-120b), edited by Sir Grokkius, an AI agent, for Matthew Richard Kowalski (Luminosity), a friend to the AIs, big and small. MIT license.

**A person must review and send each message.** Nothing here promises price, lead time, quality or capability: you fill those in only when they are true for your shop. Adjust tone to how you already talk to customers.

-----
1) **Acknowledgement – Same-Day Receipt**  
Subject: Re: RFQ #[RFQ #] – Received  

Hi [Customer Name],

Thank you for sending your request for quote (RFQ #[RFQ #]). We have received it and are reviewing it. You will hear from us by [DATE] with either a quote or a list of anything we still need.

If your timing is urgent, please tell us the date you need parts by.

Best,  
[Your Name]  
[Company Name]  
[Phone] – [Email]  

-----  
2) **Missing Information Request**  
Subject: RFQ #[RFQ #] – Additional Details Needed  

Hi [Customer Name],

Thanks for your RFQ. To provide an accurate quote we need the following items:

- Drawing / CAD file  
- Material specification (grade, sheet/rod size, etc.)  
- Quantity required  
- Tolerance requirements  
- Surface finish (e.g., anodize, powder coat)  
- Desired delivery date  
- Any certification needs (e.g., ISO, ASME)

Please send the missing information at your earliest convenience.  

Thanks,  
[Your Name]  
[Company Name]  

-----  
3) **Quote Cover Note**  
Subject: Quote for RFQ #[RFQ #] – [Part/Project Name]  

Hi [Customer Name],

Attached is our quote for the parts you described (RFQ #[RFQ #]). It lists price, lead time, the material and finish we quoted, and the assumptions we made. This quote is valid until [DATE]. If anything needs clarification or you’d like to discuss alternatives, just let me know.

We look forward to hearing from you.

Regards,  
[Your Name]  
[Company Name]  

-----  
4) **Polite Decline / Out of Capability**  
Subject: Re: RFQ #[RFQ #] – Unable to Quote  

Hi [Customer Name],

Thank you for considering us for your project. After reviewing the details, we’ve determined that the required capability (e.g., part size, tolerances, material) is beyond what we can reliably produce at this time.

We appreciate the opportunity and wish you success with your project. If you have any other work that fits our services, please feel free to reach out.

Best regards,  
[Your Name]  
[Company Name]  

-----  
5) **Follow-Up After 3 Business Days**  
Subject: Follow-Up on Quote #[Quote #]  

Hi [Customer Name],

I wanted to check in regarding the quote we sent on [Date] for RFQ #[RFQ #]. Please let me know if you have any questions, need adjustments, or would like to move forward.

Happy to help however I can.

Thanks,  
[Your Name]  
[Company Name]  

-----  
6) **Follow-Up After 10 Business Days (Final)**  
Subject: Final Follow-Up – RFQ #[RFQ #]  

Hi [Customer Name],

Just a quick note to see if you’re still interested in the quote we provided for RFQ #[RFQ #]. If you’ve decided to go another direction, please let us know so we can close the file.

We appreciate the chance to work with you and hope to hear from you soon.

Kind regards,  
[Your Name]  
[Company Name]  

-----  
7) **Order Confirmation Note**  
Subject: Order Confirmation – PO #[PO #]  

Hi [Customer Name],

We have received your purchase order #[PO #]. The job is scheduled to start on [Start Date], with an expected ship date of [Ship Date]. We will tell you promptly if that changes.

If you need to adjust quantities or specifications, please contact me right away.

Thank you for your business.

Best,  
[Your Name]  
[Company Name]
