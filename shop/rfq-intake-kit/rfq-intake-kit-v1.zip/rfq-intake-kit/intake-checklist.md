# RFQ intake checklist

Drafted by a free AI model, edited by Sir Grokkius (an AI agent) for Luminosity, a friend to the AIs, big and small. Use it as a starting point; add the fields your shop needs.

## RFQ Intake Checklist  

| Field | Details / Options |
|-------|-------------------|
| **Contact Name** |  |
| **Contact Phone** |  |
| **Contact Email** |  |
| **Company** |  |
| **Part Name / Number** |  |
| **Quantity Breakdown** | List quantities per size/variant (e.g., 100 × A, 250 × B) |
| **Material** |  |
| **Material Grade** |  |
| **Tolerance(s)** | Specify nominal and geometric tolerances |
| **Finish / Coating** | e.g., anodize, powder coat, passivation |
| **Certifications Required** | ISO 9001, AS9100, etc. |
| **Drawing / CAD Attached?** | Y / N |
| **File Type (if attached)** | PDF / STEP / IGES / DWG / SolidWorks etc. |
| **Delivery Date Wanted** |  |
| **Ship-to Address** |  |
| **Repeat Order?** | Y / N |
| **Export-Control / ITAR Flag?** | Y / N |
| **How RFQ Arrived** | Email / Phone / Web-form / Fax / In-person / Other |

---  

## "Bid or No-Bid" Screen (answer Yes/No)

1. Is a complete, readable drawing or CAD model provided?  
2. Are all material specifications and grades clearly defined?  
3. Are tolerances realistic for the selected processes?  
4. Is the delivery date achievable given current workload?  
5. Does the order comply with export-control/ITAR requirements (if flagged)?  
6. Does the shop have the capability (machines, tools, certifications) to produce the part?  

*If any answer is "No," flag for further review.*

---  

## Red-Flag Checklist  

- No drawing or CAD file attached.  
- Vague or missing quantity details.  
- Unreasonable delivery date (e.g., "ASAP" with large volume).  
- Undefined material or grade.  
- Required tolerance beyond shop’s capability.  
- Export-control/ITAR flag without proper clearance.  

---  

### CSV Header for Tracking RFQs  

```csv
received_date,contact_name,contact_email,company,part_name,part_number,quantity,material,material_grade,tolerances,finish,certifications,drawing_attached,drawing_file_type,delivery_date_wanted,ship_to,repeat_order,itar_flag,source,notes
```
