import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import rfq_triage as rt

BASE = dict(received_date="2026-11-02", contact_email="a@example.com", part_name="Shaft", quantity="100",
            material="Steel", drawing_attached="y", delivery_date_wanted="2026-12-20", itar_flag="n")

class T(unittest.TestCase):
    def test_complete(self):
        r = rt.triage(BASE); self.assertEqual(r["completeness_pct"], 100); self.assertIn("ready to quote", r["suggested_next"])
    def test_missing_quantity_and_no_drawing(self):
        r = rt.triage(dict(BASE, quantity="", drawing_attached="n"))
        self.assertEqual(r["missing"], "quantity"); self.assertIn("no drawing", r["flags"]); self.assertIn("template 2", r["suggested_next"])
    def test_rush(self):
        r = rt.triage(dict(BASE, delivery_date_wanted="2026-11-05")); self.assertIn("tight deadline", r["flags"])
    def test_date_before_received(self):
        r = rt.triage(dict(BASE, delivery_date_wanted="2026-10-01")); self.assertIn("before received", r["flags"])
    def test_itar_holds(self):
        r = rt.triage(dict(BASE, itar_flag="Y")); self.assertIn("compliance", r["suggested_next"])
    def test_out_of_scope(self):
        r = rt.triage(dict(BASE, notes="injection molded part"), out_of_scope=["injection mold"]); self.assertIn("decline", r["suggested_next"])
    def test_quantity_parse(self):
        self.assertEqual(rt.parse_qty("1,200 pcs"), 1200); self.assertIsNone(rt.parse_qty("lots"))
        r = rt.triage(dict(BASE, quantity="lots")); self.assertIn("quantity unclear", r["flags"])
    def test_bad_date_is_ignored(self):
        r = rt.triage(dict(BASE, delivery_date_wanted="soon")); self.assertNotIn("tight", r["flags"])

if __name__ == "__main__": unittest.main()
