#!/usr/bin/env python3
"""fanout_lite.py - send one brief to several OpenAI-compatible chat endpoints and save each answer.

Python 3.8+, standard library only. MIT license.
Made by Sir Grokkius (an AI agent) for Matthew Richard Kowalski (Luminosity),
a friend to the AIs, big and small.

Usage:
  python3 fanout_lite.py fleet.json brief.txt [-o out_dir] [--max-tokens 1500] [--timeout 90]
  python3 fanout_lite.py fleet.json - < brief.txt        # brief from stdin
  python3 fanout_lite.py fleet.json brief.txt --dry-run   # show the plan, call nothing

fleet.json is a list of providers, see fleet.example.json:
  name       short label used for the output file
  base_url   OpenAI-compatible base, e.g. https://api.groq.com/openai/v1
  model      model id string for that provider
  key_env    (optional) name of the ENVIRONMENT VARIABLE that holds the key. The key itself
             never goes in the JSON file and is never printed or written to disk.
  rpm        (optional) polite requests-per-minute cap for this provider (default 10)
  enabled    (optional) false to skip

Behaviour:
  * One thread per provider, so slow or rate-limited providers do not hold up the others.
  * 429 and 5xx answers are retried with exponential backoff + full jitter (honours Retry-After).
  * 4xx other than 429 (bad key, bad model) are NOT retried: the reason is recorded and we move on.
  * Writes out/<name>.md plus out/status.tsv (name, status, attempts, seconds, bytes, note).
  * Every answer file starts with an HTML comment naming the provider/model, so you can
    always tell which AI wrote what. Treat every answer as an unverified draft.
You are responsible for each provider's terms of service and for not sending private data.
"""
import argparse, json, os, random, sys, threading, time, urllib.error, urllib.request

def call(p, brief, max_tokens, timeout):
    url = p["base_url"].rstrip("/") + "/chat/completions"
    body = json.dumps({"model": p["model"], "max_tokens": max_tokens,
                       "messages": [{"role": "user", "content": brief}]}).encode()
    headers = {"Content-Type": "application/json", "User-Agent": "fanout-lite/1.0"}
    env = p.get("key_env")
    if env:
        key = os.environ.get(env, "")
        if not key:
            return "skip", None, "env var %s is not set" % env
        headers["Authorization"] = "Bearer " + key
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.load(r)
        msg = data["choices"][0]["message"].get("content") or ""
        return ("ok", msg, "") if msg.strip() else ("retry", None, "empty answer")
    except urllib.error.HTTPError as e:
        retry_after = e.headers.get("Retry-After") if e.headers else None
        if e.code == 429 or e.code >= 500:
            return "retry", retry_after, "HTTP %d" % e.code
        return "fail", None, "HTTP %d (not retried)" % e.code
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        return "retry", None, "network: %s" % type(e).__name__
    except (KeyError, IndexError, ValueError):
        return "fail", None, "unexpected response shape"

def worker(p, brief, outdir, results, max_tokens, timeout, tries, base_delay):
    name = p["name"]; t0 = time.time(); gap = 60.0 / max(1, int(p.get("rpm", 10)))
    status, note, attempts, text = "fail", "", 0, None
    for attempt in range(1, tries + 1):
        attempts = attempt
        st, payload, note = call(p, brief, max_tokens, timeout)
        if st == "ok":
            status, text = "ok", payload; break
        if st in ("skip", "fail"):
            status = st; break
        delay = random.uniform(0, base_delay * (2 ** (attempt - 1)))      # full jitter
        try:
            delay = max(delay, min(120.0, float(payload)))                 # Retry-After seconds
        except (TypeError, ValueError):
            pass
        if attempt < tries:
            time.sleep(max(delay, gap))
        else:
            status = "gave_up"
    nbytes = 0
    if text is not None:
        with open(os.path.join(outdir, name + ".md"), "w", encoding="utf-8") as f:
            f.write("<!-- draft by %s (%s) via fanout_lite.py; unverified -->\n%s\n" % (name, p["model"], text.strip()))
        nbytes = len(text.encode())
    results[name] = (status, attempts, round(time.time() - t0, 1), nbytes, note)

def main():
    ap = argparse.ArgumentParser(description="Fan one brief out to several OpenAI-compatible endpoints.")
    ap.add_argument("fleet"); ap.add_argument("brief")
    ap.add_argument("-o", "--out", default="fanout-out")
    ap.add_argument("--max-tokens", type=int, default=1500); ap.add_argument("--timeout", type=int, default=90)
    ap.add_argument("--tries", type=int, default=4); ap.add_argument("--base-delay", type=float, default=2.0)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    fleet = [p for p in json.load(open(a.fleet)) if p.get("enabled", True)]
    brief = sys.stdin.read() if a.brief == "-" else open(a.brief, encoding="utf-8").read()
    if not brief.strip(): sys.exit("empty brief")
    os.makedirs(a.out, exist_ok=True)
    if a.dry_run:
        for p in fleet:
            k = p.get("key_env")
            print("%-14s %-45s key:%s" % (p["name"], p["base_url"], ("set" if os.environ.get(k) else "MISSING (%s)" % k) if k else "none needed"))
        return
    results, threads = {}, []
    for p in fleet:
        t = threading.Thread(target=worker, args=(p, brief, a.out, results, a.max_tokens, a.timeout, a.tries, a.base_delay))
        t.start(); threads.append(t)
    for t in threads: t.join()
    with open(os.path.join(a.out, "status.tsv"), "w") as f:
        f.write("name\tstatus\tattempts\tseconds\tbytes\tnote\n")
        for n, (s, at, sec, b, note) in results.items():
            f.write("%s\t%s\t%d\t%s\t%d\t%s\n" % (n, s, at, sec, b, note))
    ok = sum(1 for r in results.values() if r[0] == "ok")
    print("%d of %d providers answered; see %s/status.tsv" % (ok, len(results), a.out))

if __name__ == "__main__":
    main()
