# Prompt templates for a free-AI fleet

Ten reusable templates. Replace the [PLACEHOLDERS]. Each template works with any chat model.
Drafted by a free AI model (Groq-hosted gpt-oss-120b), then edited by Sir Grokkius, an AI agent, for Matthew Richard Kowalski (Luminosity), a friend to the AIs, big and small. MIT license.

Note on the 'AI-disclosure' template: change the disclosure sentence to match your own situation. The point is that readers can tell what was AI-assisted.

---

### 1. Shared Brief for All Models  
*Use this when you need every AI model to start from the exact same context and constraints.*

```
You are an expert writer specializing in [TOPIC].  
Target audience: [AUDIENCE].  
Desired tone/voice: [STYLE] (e.g., professional, conversational, persuasive).  
Length requirement: [WORD_COUNT] words (or ~[CHAR_COUNT] characters).  
Key points to cover (in order):  
1. [KEY_POINT_1]  
2. [KEY_POINT_2]  
3. [KEY_POINT_3]  
Do not invent facts, numbers, quotes or sources. If you are not sure of something, write UNSURE next to it.  
Output the draft ONLY (no explanations, no headings).  
```

---

### 2. Strict-Format Answer Wrapper  
*Apply this when you need the response in a machine-readable structure for downstream processing.*

```
Provide your answer exactly in the following JSON format, without any extra text or comments:

{
  "title": "[TITLE]",
  "summary": "[SHORT_SUMMARY]",
  "sections": [
    {
      "heading": "[HEADING_1]",
      "content": "[CONTENT_1]"
    },
    {
      "heading": "[HEADING_2]",
      "content": "[CONTENT_2]"
    }
    // add more sections as needed
  ],
  "conclusion": "[CONCLUSION]",
  "references": [
    {
      "description": "[SOURCE_DESCRIPTION]",
      "url": "[SOURCE_URL]"
    }
  ]
}
```

---

### 3. Devil’s-Advocate Critic  
*Use when you want a second model to challenge the validity, completeness, or bias of another model’s answer.*

```
You are a skeptical analyst. Review the answer below and identify:

1. Any factual inaccuracies or unverified claims.  
2. Logical gaps, missing context, or unsupported assumptions.  
3. Potential bias in tone, perspective, or source selection.  
4. Suggested improvements or counter-arguments.

Answer must be structured as:

- **Inaccuracies:** …  
- **Gaps:** …  
- **Biases:** …  
- **Recommendations:** …

Answer (do not quote the original text, just reference line numbers if needed):
[MODEL_ANSWER]
```

---

### 4. Claim Extractor  
*Run this to pull out every checkable factual claim from a draft for verification.*

```
Read the text below and extract every claim that can be fact-checked (including dates, prices, statistics, names, and specific events). Return a markdown table with the columns:

| Claim ID | Exact Claim Text | Claim Type (Date/Price/Statistic/Name/Event) | Verifiable? (Yes/No) |

List claims sequentially (C1, C2, …). If a claim is vague or subjective, mark Verifiable? as "No".
Text to analyze:
[FULL_DRAFT]
```

---

### 5. Source-Quote Demand  
*Ask for a quoted source for every factual claim, otherwise label it UNVERIFIED. A plain chat model cannot browse and may invent a quote or a URL, so open every link yourself; this prompt gives you a list to check, not proof.*

```
For each claim in the table below, provide a direct quotation from a reliable source that supports it, together with the source URL. If no source can be found, replace the claim text with the word **UNVERIFIED**.

| Claim ID | Claim Text | Supporting Quote | Source URL |
|----------|------------|------------------|------------|
[CLAIM_TABLE]
```

---

### 6. Merge-and-Reconcile of Three Model Answers  
*Combine three different drafts, highlight disagreements, and produce a unified version.*

```
You have three versions of the same document:

- Answer A: [MODEL_A_ANSWER]  
- Answer B: [MODEL_B_ANSWER]  
- Answer C: [MODEL_C_ANSWER]

Tasks:
1. List any contradictory statements or differing data points in a table (Item, A, B, C).
2. For each conflict, choose the most reliable version (explain briefly why).
3. Produce a single merged draft that incorporates the chosen content, preserving the original structure (headings, sections).

Output format:
**Conflicts Table**
| Item | A | B | C |
|------|---|---|---|

**Merged Draft**
[MERGED_CONTENT]
```

---

### 7. Tone/Voice Rewrite with AI-Disclosure  
*Re-tone a piece while inserting a mandatory disclosure that AI assistance was used.*

```
Rewrite the following text to match the desired tone: [TARGET_TONE] (e.g., formal, friendly, urgent). Preserve all factual information and length as much as possible. At the end of the document, add a disclaimer line exactly as:

*“This content was generated with the assistance of artificial intelligence.”*

Original text:
[ORIGINAL_DRAFT]
```

---

### 8. Shorten-to-N-Characters  
*Compress the content to fit a strict character limit without losing key information.*

```
Condense the text below to **no more than [CHAR_LIMIT] characters** (including spaces). Keep the core message, main facts, and call-to-action. If you must omit details, prioritize removing examples or secondary points. Return only the shortened text, no explanations.

Text to shorten:
[FULL_TEXT]
```

---

### 9. Red-Team for Hype and Income Claims  
*Stress-test the draft for exaggerated or unverifiable financial promises.*

```
You are a red-team analyst. Scan the document and flag any statements that:

- Overpromise results or income (e.g., “earn $10,000 per month”).
- Use hype language (“guaranteed success”, “the ultimate solution”).
- Lack concrete evidence.

For each flagged item, provide:
1. The exact sentence.
2. Reason for flagging.
3. Suggested neutral re-phrasing.

Document:
[CONTENT_TO_REVIEW]
```

---

### 10. Final Pre-Publish Checklist Prompt  
*Run this checklist before publishing to ensure completeness, compliance, and quality.*

```
Perform a final audit of the draft using the following checklist. Answer "Yes" or "No" for each item and add brief comments if "No".

- [ ] All factual claims are verified with a source URL.  
- [ ] Nothing was copied from another source without credit.  
- [ ] Tone matches the target audience and style guide.  
- [ ] AI-disclosure line is present.  
- [ ] No hype, unrealistic income, or medical/legal advice beyond scope.  
- [ ] Word/character count within the specified limit ([LIMIT]).  
- [ ] All hyperlinks open and go where the text says.  
- [ ] Accessibility: headings are logical, alt-text described where needed.  

Provide the completed checklist and any required edits:
[FINAL_DRAFT]
```
