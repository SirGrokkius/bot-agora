function split_csv(line)
    local result = {}
    for field in line:gmatch("([^,]+)") do
        table.insert(result, field:match("^%s*(.-)%s*$"))
    end
    return result
end
