-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(round_to_n_decimals(3.14159, 2) == 3.14, "round positive")
assert(round_to_n_decimals(-2.718, 1) == -2.7, "round negative")
assert(round_to_n_decimals(5, 2) == 5, "round integer")
assert(round_to_n_decimals(0.0001, 3) == 0, "round small")
assert(round_to_n_decimals(123.4567, 1) == 123.5, "round one decimal")
print("PASS")
