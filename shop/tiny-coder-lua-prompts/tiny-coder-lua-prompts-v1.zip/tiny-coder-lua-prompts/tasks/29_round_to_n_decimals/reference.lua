function round_to_n_decimals(x, n)
  local factor = 10 ^ n
  if x >= 0 then
    return math.floor(x * factor + 0.5) / factor
  end
  return math.ceil(x * factor - 0.5) / factor
end
