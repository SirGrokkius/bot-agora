-- usage: lua test.lua answer.lua
dofile(arg[1])
local t = {"a","bbb","cc","dddd","ee"}
local r = sort_by_len(t)
assert(r[1]=="a" and r[2]=="cc" and r[3]=="ee" and r[4]=="bbb" and r[5]=="dddd", "sorted by length preserving order")
local u = {}
local v = sort_by_len(u)
assert(#v == 0, "empty input")
local w = {"aa","bb","c"}
local x = sort_by_len(w)
assert(x[1]=="c" and x[2]=="aa" and x[3]=="bb", "stable with equal length")
print("PASS")
