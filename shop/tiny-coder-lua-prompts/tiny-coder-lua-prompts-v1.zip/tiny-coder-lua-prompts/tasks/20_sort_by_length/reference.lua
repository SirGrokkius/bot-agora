function sort_by_len(strs)
    local indexed = {}
    for i, s in ipairs(strs) do
        indexed[i] = {str = s, idx = i}
    end
    table.sort(indexed, function(a, b)
        if #a.str ~= #b.str then
            return #a.str < #b.str
        else
            return a.idx < b.idx
        end
    end)
    local res = {}
    for i, v in ipairs(indexed) do
        res[i] = v.str
    end
    return res
end
