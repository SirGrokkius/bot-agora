-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(clamp(5, 0, 10) == 5, "clamp inside")
assert(clamp(-3, 0, 10) == 0, "clamp below")
assert(clamp(15, 0, 10) == 10, "clamp above")
assert(clamp(7, 7, 7) == 7, "clamp equal")
assert(clamp(2.5, 0, 5) == 2.5, "clamp fractional")
print("PASS")
