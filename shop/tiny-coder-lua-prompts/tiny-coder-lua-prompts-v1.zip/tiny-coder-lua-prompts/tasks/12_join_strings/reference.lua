function join(arr, sep)
  return table.concat(arr, sep)
end
