-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(join({"a", "b", "c"}, ", ") == "a, b, c")
assert(join({}, "-") == "")
assert(join({"solo"}, "-") == "solo")
assert(join({"x", "y"}, "") == "xy")
print("PASS")
