-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(sum_array({1, 2, 3}) == 6, "basic sum")
assert(sum_array({}) == 0, "empty array")
assert(sum_array({-5, 5}) == 0, "mixed signs")
assert(sum_array({10}) == 10, "single element")
assert(sum_array({0, 0, 0}) == 0, "all zeros")
print("PASS")
