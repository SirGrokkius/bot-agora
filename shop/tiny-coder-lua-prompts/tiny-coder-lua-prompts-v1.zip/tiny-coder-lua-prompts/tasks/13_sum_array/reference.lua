function sum_array(arr)
  local s = 0
  for i = 1, #arr do
    s = s + arr[i]
  end
  return s
end
