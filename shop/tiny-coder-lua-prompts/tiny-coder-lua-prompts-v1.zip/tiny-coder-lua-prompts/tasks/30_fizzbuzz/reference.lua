function fizzbuzz(n)
  local r = {}
  for i = 1, n do
    if i % 15 == 0 then r[i] = "FizzBuzz"
    elseif i % 3 == 0 then r[i] = "Fizz"
    elseif i % 5 == 0 then r[i] = "Buzz"
    else r[i] = tostring(i) end
  end
  return r
end
