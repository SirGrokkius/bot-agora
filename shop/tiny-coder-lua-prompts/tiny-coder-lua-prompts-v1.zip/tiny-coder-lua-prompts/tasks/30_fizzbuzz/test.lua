-- usage: lua test.lua answer.lua
dofile(arg[1])
local r = fizzbuzz(15)
assert(#r == 15)
assert(r[1] == "1" and r[3] == "Fizz" and r[5] == "Buzz" and r[15] == "FizzBuzz" and r[14] == "14")
assert(#fizzbuzz(0) == 0)
print("PASS")
