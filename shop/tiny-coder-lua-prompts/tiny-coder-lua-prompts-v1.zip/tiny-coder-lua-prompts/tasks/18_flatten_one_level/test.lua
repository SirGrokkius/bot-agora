-- usage: lua test.lua answer.lua
dofile(arg[1])
local r = flatten_one_level({1, {2, 3}, 4, {}, {5}})
assert(#r == 5 and r[1] == 1 and r[2] == 2 and r[3] == 3 and r[4] == 4 and r[5] == 5)
assert(#flatten_one_level({}) == 0)
local d = flatten_one_level({{1, {2}}})
assert(#d == 2 and d[1] == 1 and type(d[2]) == "table" and d[2][1] == 2)
print("PASS")
