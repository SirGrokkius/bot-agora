function flatten_one_level(arr)
  local r = {}
  for _, v in ipairs(arr) do
    if type(v) == "table" then
      for _, w in ipairs(v) do r[#r + 1] = w end
    else
      r[#r + 1] = v
    end
  end
  return r
end
