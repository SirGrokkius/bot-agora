function trim(s)
    return s:match("^%s*(.-)%s*$") or ""
end
