-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(trim("  hello  ") == "hello", "spaces")
assert(trim("\t\nfoo\t") == "foo", "tabs and newlines")
assert(trim("nochange") == "nochange", "no whitespace")
assert(trim("") == "", "empty")
assert(trim("   ") == "", "only spaces")
print("PASS")
