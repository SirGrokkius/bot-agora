function remove_duplicates(arr)
  local seen = {}
  local res = {}
  for i = 1, #arr do
    local v = arr[i]
    if not seen[v] then
      seen[v] = true
      res[#res + 1] = v
    end
  end
  return res
end
