-- usage: lua test.lua answer.lua
dofile(arg[1])
local function eq(a, b)
  if #a ~= #b then return false end
  for i = 1, #a do
    if a[i] ~= b[i] then return false end
  end
  return true
end
assert(eq(remove_duplicates({1, 2, 1, 3, 2}), {1, 2, 3}), "repeats")
assert(eq(remove_duplicates({}), {}), "empty")
assert(eq(remove_duplicates({5, 5, 5}), {5}), "all same")
assert(eq(remove_duplicates({0, -1, 0, -1, 2}), {0, -1, 2}), "mixed")
assert(eq(remove_duplicates({1, 2, 3}), {1, 2, 3}), "no duplicates")
print("PASS")
