function is_palindrome(s)
    local cleaned = s:lower():gsub("[^%w]", "")
    return cleaned == cleaned:reverse()
end
