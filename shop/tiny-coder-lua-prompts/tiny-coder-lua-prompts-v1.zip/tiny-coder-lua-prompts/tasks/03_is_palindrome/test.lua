-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(is_palindrome("Madam, I'm Adam") == true, "famous phrase")
assert(is_palindrome("racecar") == true, "simple palindrome")
assert(is_palindrome("Hello") == false, "not a palindrome")
assert(is_palindrome("") == true, "empty string")
assert(is_palindrome("A man a plan a canal Panama") == true, "long phrase")
print("PASS")
