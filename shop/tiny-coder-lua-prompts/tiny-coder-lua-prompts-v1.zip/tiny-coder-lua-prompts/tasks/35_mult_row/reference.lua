function mult_row(n, upto)
  local r = {}
  for i = 1, upto do r[i] = n * i end
  return r
end
