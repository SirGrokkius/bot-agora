-- usage: lua test.lua answer.lua
dofile(arg[1])
local r = mult_row(7, 4)
assert(#r == 4 and r[1] == 7 and r[2] == 14 and r[3] == 21 and r[4] == 28)
assert(#mult_row(5, 0) == 0)
assert(mult_row(0, 3)[3] == 0)
print("PASS")
