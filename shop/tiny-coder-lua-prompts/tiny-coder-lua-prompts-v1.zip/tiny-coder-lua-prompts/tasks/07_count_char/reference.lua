function count_char(s, ch)
    local cnt = 0
    for i = 1, #s do
        if s:sub(i, i) == ch then cnt = cnt + 1 end
    end
    return cnt
end
