-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(count_char("banana", "a") == 3, "a in banana")
assert(count_char("mississippi", "s") == 4, "s count")
assert(count_char("", "x") == 0, "empty string")
assert(count_char("abc", "d") == 0, "absent char")
assert(count_char("111111", "1") == 6, "digits")
print("PASS")
