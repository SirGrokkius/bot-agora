function freq_table(text)
    local counts = {}
    for w in text:lower():gmatch("%a+") do
        counts[w] = (counts[w] or 0) + 1
    end
    return counts
end
