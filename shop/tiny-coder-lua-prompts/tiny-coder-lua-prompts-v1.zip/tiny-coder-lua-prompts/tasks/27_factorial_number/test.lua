-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(factorial(0) == 1, "factorial(0)")
assert(factorial(1) == 1, "factorial(1)")
assert(factorial(3) == 6, "factorial(3)")
assert(factorial(5) == 120, "factorial(5)")
assert(factorial(10) == 3628800, "factorial(10)")
print("PASS")
