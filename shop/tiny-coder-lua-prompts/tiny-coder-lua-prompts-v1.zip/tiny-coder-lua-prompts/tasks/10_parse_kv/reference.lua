function parse_kv(s)
    local tbl = {}
    for pair in s:gmatch("[^,]+") do
        local k, v = pair:match("^%s*(%S-)%s*=%s*(%S-)%s*$")
        if k then tbl[k] = v end
    end
    return tbl
end
