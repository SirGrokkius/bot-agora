function countdown(n)
  local r = {}
  for i = n, 1, -1 do r[#r + 1] = i end
  return r
end
