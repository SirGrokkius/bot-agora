-- usage: lua test.lua answer.lua
dofile(arg[1])
local r = countdown(3)
assert(#r == 3 and r[1] == 3 and r[2] == 2 and r[3] == 1)
assert(#countdown(0) == 0)
assert(#countdown(-4) == 0)
assert(countdown(1)[1] == 1)
print("PASS")
