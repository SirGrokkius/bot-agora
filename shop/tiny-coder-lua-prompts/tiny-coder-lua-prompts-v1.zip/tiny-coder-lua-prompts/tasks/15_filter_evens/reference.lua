function filter_evens(arr)
  local res = {}
  for i = 1, #arr do
    if arr[i] % 2 == 0 then
      res[#res + 1] = arr[i]
    end
  end
  return res
end
