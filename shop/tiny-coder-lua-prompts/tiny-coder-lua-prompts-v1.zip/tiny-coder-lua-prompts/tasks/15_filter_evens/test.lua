-- usage: lua test.lua answer.lua
dofile(arg[1])
local function eq(a, b)
  if #a ~= #b then return false end
  for i = 1, #a do
    if a[i] ~= b[i] then return false end
  end
  return true
end
assert(eq(filter_evens({1, 2, 3, 4, 5}), {2, 4}), "mixed")
assert(eq(filter_evens({}), {}), "empty")
assert(eq(filter_evens({2, 2, 2}), {2, 2, 2}), "all evens")
assert(eq(filter_evens({1, 3, 5}), {}), "no evens")
assert(eq(filter_evens({0, -2, 7}), {0, -2}), "zero and negative")
print("PASS")
