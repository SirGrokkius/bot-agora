-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(fibonacci(0) == 0, "fibonacci(0)")
assert(fibonacci(1) == 1, "fibonacci(1)")
assert(fibonacci(2) == 1, "fibonacci(2)")
assert(fibonacci(5) == 5, "fibonacci(5)")
assert(fibonacci(10) == 55, "fibonacci(10)")
print("PASS")
