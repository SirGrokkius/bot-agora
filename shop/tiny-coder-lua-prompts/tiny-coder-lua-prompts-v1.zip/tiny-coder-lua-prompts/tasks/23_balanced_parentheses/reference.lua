function is_balanced(s)
    local depth = 0
    for i = 1, #s do
        local c = s:sub(i,i)
        if c == '(' then
            depth = depth + 1
        elseif c == ')' then
            depth = depth - 1
            if depth < 0 then return false end
        end
    end
    return depth == 0
end
