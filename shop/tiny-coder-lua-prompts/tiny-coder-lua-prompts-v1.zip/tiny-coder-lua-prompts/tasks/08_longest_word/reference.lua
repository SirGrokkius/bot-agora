function longest_word(s)
    local best = ""
    for w in s:gmatch("%a+") do
        if #w > #best then best = w end
    end
    return best
end
