-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(longest_word("The quick brown fox") == "quick", "simple")
assert(longest_word("abc abcde abcdef") == "abcdef", "longest at end")
assert(longest_word("123 456") == "", "no letters")
assert(longest_word("") == "", "empty input")
assert(longest_word("Hello, world!") == "Hello", "punctuation")
print("PASS")
