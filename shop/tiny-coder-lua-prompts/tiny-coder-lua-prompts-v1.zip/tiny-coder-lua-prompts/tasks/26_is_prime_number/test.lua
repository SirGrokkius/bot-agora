-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(is_prime(2) == true, "is_prime(2)")
assert(is_prime(1) == false, "is_prime(1)")
assert(is_prime(0) == false, "is_prime(0)")
assert(is_prime(9) == false, "is_prime(9)")
assert(is_prime(17) == true, "is_prime(17)")
assert(is_prime(20) == false, "is_prime(20)")
print("PASS")
