function is_prime(n)
  if type(n) ~= "number" or n < 2 or n % 1 ~= 0 then
    return false
  end
  if n == 2 then
    return true
  end
  if n % 2 == 0 then
    return false
  end
  local i = 3
  while i * i <= n do
    if n % i == 0 then
      return false
    end
    i = i + 2
  end
  return true
end
