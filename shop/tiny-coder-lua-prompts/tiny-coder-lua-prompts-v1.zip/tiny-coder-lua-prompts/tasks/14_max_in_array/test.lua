-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(max_in_array({1, 3, 2}) == 3, "normal case")
assert(max_in_array({-10, -5, -7}) == -5, "negative numbers")
assert(max_in_array({5}) == 5, "single element")
assert(max_in_array({}) == nil, "empty array")
assert(max_in_array({0, 0, 0}) == 0, "all zeros")
print("PASS")
