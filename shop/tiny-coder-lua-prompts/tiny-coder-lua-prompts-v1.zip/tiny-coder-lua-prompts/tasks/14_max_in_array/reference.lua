function max_in_array(arr)
  if #arr == 0 then return nil end
  local m = arr[1]
  for i = 2, #arr do
    if arr[i] > m then m = arr[i] end
  end
  return m
end
