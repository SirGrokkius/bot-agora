function title_case(s)
    local result = {}
    for word in s:gmatch("%S+") do
        local t = word:sub(1,1):upper() .. word:sub(2):lower()
        table.insert(result, t)
    end
    return table.concat(result, " ")
end
