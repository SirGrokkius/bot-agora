-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(title_case("hello world") == "Hello World", "basic")
assert(title_case("LUA programming LANGUAGE") == "Lua Programming Language", "mixed case")
assert(title_case("") == "", "empty")
assert(title_case("   multiple   spaces   ") == "Multiple Spaces", "collapse spaces")
assert(title_case("a") == "A", "single letter")
print("PASS")
