-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(collatz_steps(1) == 0)
assert(collatz_steps(2) == 1)
assert(collatz_steps(6) == 8)
assert(collatz_steps(27) == 111)
print("PASS")
