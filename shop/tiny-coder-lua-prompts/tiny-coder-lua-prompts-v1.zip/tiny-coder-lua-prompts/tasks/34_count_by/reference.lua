function count_by(n, k)
  local r = {}
  for v = k, n, k do r[#r + 1] = v end
  return r
end
