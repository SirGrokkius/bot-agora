-- usage: lua test.lua answer.lua
dofile(arg[1])
local r = count_by(10, 3)
assert(#r == 3 and r[1] == 3 and r[2] == 6 and r[3] == 9)
assert(#count_by(2, 5) == 0)
assert(#count_by(10, 5) == 2 and count_by(10, 5)[2] == 10)
assert(#count_by(5, 1) == 5)
print("PASS")
