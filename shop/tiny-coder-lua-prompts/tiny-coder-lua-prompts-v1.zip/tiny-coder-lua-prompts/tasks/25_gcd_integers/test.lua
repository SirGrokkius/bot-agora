-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(gcd(12, 8) == 4, "gcd(12,8)")
assert(gcd(0, 5) == 5, "gcd(0,5)")
assert(gcd(7, 7) == 7, "gcd(7,7)")
assert(gcd(100, 35) == 5, "gcd(100,35)")
assert(gcd(-12, 18) == 6, "gcd(-12,18)")
print("PASS")
