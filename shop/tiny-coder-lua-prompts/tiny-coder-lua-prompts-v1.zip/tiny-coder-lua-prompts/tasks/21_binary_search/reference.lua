function binary_search(arr, target)
    local lo, hi = 1, #arr
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        local val = arr[mid]
        if val == target then
            return mid
        elseif val < target then
            lo = mid + 1
        else
            hi = mid - 1
        end
    end
    return nil
end
