-- usage: lua test.lua answer.lua
dofile(arg[1])
local a = {1,3,5,7,9}
assert(binary_search(a, 1) == 1, "first element")
assert(binary_search(a, 9) == 5, "last element")
assert(binary_search(a, 5) == 3, "middle element")
assert(binary_search(a, 2) == nil, "absent element")
assert(binary_search({}, 1) == nil, "empty array")
local b = {2,2,2,2}
assert(binary_search(b, 2) ~= nil, "duplicate present")
print("PASS")
