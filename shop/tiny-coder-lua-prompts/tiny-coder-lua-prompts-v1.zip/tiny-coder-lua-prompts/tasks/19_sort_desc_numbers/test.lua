-- usage: lua test.lua answer.lua
dofile(arg[1])
local a = {3,1,4,1,5,9}
local b = sort_desc(a)
assert(b[1]==9 and b[2]==5 and b[3]==4 and b[4]==3 and b[5]==1 and b[6]==1, "descending order")
local c = {}
assert(#sort_desc(c) == 0, "empty table")
local d = {2,2,2}
local e = sort_desc(d)
assert(e[1]==2 and e[2]==2 and e[3]==2, "all equal")
print("PASS")
