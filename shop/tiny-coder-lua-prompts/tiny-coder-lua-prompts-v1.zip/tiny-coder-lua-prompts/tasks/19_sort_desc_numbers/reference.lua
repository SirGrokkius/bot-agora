function sort_desc(nums)
    local res = {}
    for i = 1, #nums do res[i] = nums[i] end
    table.sort(res, function(a,b) return a > b end)
    return res
end
