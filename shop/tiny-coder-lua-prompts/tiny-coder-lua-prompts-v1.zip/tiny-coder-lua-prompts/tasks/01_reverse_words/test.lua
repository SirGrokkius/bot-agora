-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(reverse_words("hello world") == "world hello", "basic two words")
assert(reverse_words("  multiple   spaces  ") == "spaces multiple", "collapse spaces")
assert(reverse_words("Lua") == "Lua", "single word")
assert(reverse_words("") == "", "empty string")
assert(reverse_words("a b c d") == "d c b a", "multiple words")
print("PASS")
