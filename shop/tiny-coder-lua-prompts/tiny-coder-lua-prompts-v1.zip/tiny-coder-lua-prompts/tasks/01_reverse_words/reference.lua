function reverse_words(s)
    local words = {}
    for word in s:gmatch("%S+") do
        table.insert(words, 1, word)
    end
    return table.concat(words, " ")
end
