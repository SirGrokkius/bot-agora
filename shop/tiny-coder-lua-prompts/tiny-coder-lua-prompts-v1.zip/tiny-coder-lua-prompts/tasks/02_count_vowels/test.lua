-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(count_vowels("hello") == 2, "hello")
assert(count_vowels("ABCDEFGHIJKLMNOPQRSTUVWXYZ") == 5, "uppercase alphabet")
assert(count_vowels("bcdfg") == 0, "no vowels")
assert(count_vowels("") == 0, "empty string")
assert(count_vowels("AeIoU") == 5, "mixed case")
print("PASS")
