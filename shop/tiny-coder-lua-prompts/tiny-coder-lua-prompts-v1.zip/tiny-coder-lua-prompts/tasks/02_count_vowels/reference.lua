function count_vowels(s)
    local count = 0
    for c in s:lower():gmatch(".") do
        if c:find("[aeiou]") then count = count + 1 end
    end
    return count
end
