-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(sum_of_digits(0) == 0)
assert(sum_of_digits(7) == 7)
assert(sum_of_digits(123) == 6)
assert(sum_of_digits(9999) == 36)
assert(sum_of_digits(1000) == 1)
print("PASS")
