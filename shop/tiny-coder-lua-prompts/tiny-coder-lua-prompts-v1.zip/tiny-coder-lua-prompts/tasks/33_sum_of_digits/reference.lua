function sum_of_digits(n)
  local s = 0
  while n > 0 do
    s = s + n % 10
    n = n // 10
  end
  return s
end
