-- usage: lua test.lua answer.lua
dofile(arg[1])
assert(caesar("abc", 1) == "bcd", "simple forward")
assert(caesar("XYZ", 2) == "ZAB", "wrap uppercase")
assert(caesar("Hello, World!", 5) == "Mjqqt, Btwqi!", "mixed")
assert(caesar("Lua", -1) == "Ktz", "negative shift")
assert(caesar("123!", 10) == "123!", "non‑letters")
print("PASS")
