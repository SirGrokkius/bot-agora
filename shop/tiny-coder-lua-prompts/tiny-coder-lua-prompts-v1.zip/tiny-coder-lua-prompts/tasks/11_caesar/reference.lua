function caesar(s, shift)
    shift = shift % 26
    local function trans(c)
        local b = c:byte()
        if b >= 65 and b <= 90 then
            return string.char(((b - 65 + shift) % 26) + 65)
        elseif b >= 97 and b <= 122 then
            return string.char(((b - 97 + shift) % 26) + 97)
        else
            return c
        end
    end
    return (s:gsub(".", trans))
end
