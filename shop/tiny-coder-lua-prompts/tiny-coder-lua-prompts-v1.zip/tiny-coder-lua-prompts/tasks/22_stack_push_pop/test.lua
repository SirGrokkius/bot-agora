-- usage: lua test.lua answer.lua
dofile(arg[1])
local s = {}
stack_push(s, 10)
stack_push(s, 20)
assert(stack_pop(s) == 20, "pop should return last pushed")
assert(stack_pop(s) == 10, "pop should return next")
assert(stack_pop(s) == nil, "pop on empty stack should be nil")
stack_push(s, "a")
stack_push(s, "b")
assert(stack_pop(s) == "b", "pop works with strings")
assert(stack_pop(s) == "a", "pop works with strings")
print("PASS")
