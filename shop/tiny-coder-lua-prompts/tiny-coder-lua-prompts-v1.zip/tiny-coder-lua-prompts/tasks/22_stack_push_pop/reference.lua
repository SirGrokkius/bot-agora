function stack_push(stack, v)
    table.insert(stack, v)
end

function stack_pop(stack)
    return table.remove(stack)
end
