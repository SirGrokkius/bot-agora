function map_double(arr)
  local res = {}
  for i = 1, #arr do
    res[i] = arr[i] * 2
  end
  return res
end
