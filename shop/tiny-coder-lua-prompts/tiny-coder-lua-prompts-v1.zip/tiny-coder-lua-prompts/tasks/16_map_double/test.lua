-- usage: lua test.lua answer.lua
dofile(arg[1])
local function eq(a, b)
  if #a ~= #b then return false end
  for i = 1, #a do
    if a[i] ~= b[i] then return false end
  end
  return true
end
assert(eq(map_double({1, 2, 3}), {2, 4, 6}), "basic")
assert(eq(map_double({}), {}), "empty")
assert(eq(map_double({0, -5}), {0, -10}), "zero and negative")
assert(eq(map_double({5}), {10}), "single")
assert(eq(map_double({-1, 1}), {-2, 2}), "mixed signs")
print("PASS")
