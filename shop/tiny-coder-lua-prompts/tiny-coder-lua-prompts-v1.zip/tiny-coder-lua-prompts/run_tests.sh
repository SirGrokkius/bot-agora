#!/usr/bin/env bash
# run_tests.sh — check answers against the tests in tasks/.
#   ./run_tests.sh --reference        run every test against the bundled reference solution (self-check)
#   ./run_tests.sh answers/           run each answers/<id>.lua  (id = folder name without the NN_ prefix,
#                                     e.g. answers/reverse_words.lua)
# Needs a `lua` (5.3 or 5.4) on PATH. Set LUA=/path/to/lua to use another binary.
LUA="${LUA:-lua}"
cd "$(dirname "$0")"
mode="${1:---reference}"
pass=0; fail=0; skip=0
for d in tasks/*/; do
  name="$(basename "$d")"; id="${name#*_}"
  if [ "$mode" = "--reference" ]; then ans="$d/reference.lua"; else ans="$mode/$id.lua"; fi
  if [ ! -f "$ans" ]; then skip=$((skip+1)); continue; fi
  if out="$("$LUA" "$d/test.lua" "$ans" 2>&1)" && [ "$out" = "PASS" ]; then
    echo "PASS  $name"; pass=$((pass+1))
  else
    echo "FAIL  $name :: $(echo "$out" | head -1)"; fail=$((fail+1))
  fi
done
echo "passed=$pass failed=$fail skipped(no answer file)=$skip"
[ "$fail" -eq 0 ]
