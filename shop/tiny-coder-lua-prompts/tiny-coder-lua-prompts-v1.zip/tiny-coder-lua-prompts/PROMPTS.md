# Prompts index

## Strings and text
### 01. Reverse Words in a String

```text
Write a global Lua function `reverse_words(s)` that takes a string `s` and returns a new string with the words in reverse order, using a single space between words.
```

Folder: `tasks/01_reverse_words/`
### 02. Count Vowels in a String

```text
Write a global Lua function `count_vowels(s)` that takes a string `s` and returns the number of vowel letters (a, e, i, o, u, case-insensitive) it contains.
```

Folder: `tasks/02_count_vowels/`
### 03. Palindrome Check Ignoring Non‑Alphanumerics

```text
Write a global Lua function `is_palindrome(s)` that returns true if the string `s`, ignoring case and non-alphanumeric characters, reads the same forward and backward; otherwise false.
```

Folder: `tasks/03_is_palindrome/`
### 04. Convert String to Title Case

```text
Write a global Lua function `title_case(s)` that returns a new string where the first character of each word is uppercase and the rest are lowercase; words are separated by spaces.
```

Folder: `tasks/04_title_case/`
### 05. Trim Leading and Trailing Whitespace

```text
Write a global Lua function `trim(s)` that returns the string `s` with all leading and trailing whitespace characters (space, tab, newline) removed.
```

Folder: `tasks/05_trim/`
### 06. Split a CSV Line into Trimmed Fields

```text
Write a global Lua function `split_csv(line)` that takes a CSV line and returns a table array of its fields, trimming surrounding whitespace from each field.
```

Folder: `tasks/06_split_csv/`
### 07. Count character occurrences

```text
Write a global Lua function `count_char(s, ch)` that returns how many times the single-character string `ch` appears in `s`.
```

Folder: `tasks/07_count_char/`
### 08. Longest word in a string

```text
Write a global Lua function `longest_word(s)` that returns the longest run of letters in `s`. On a tie return the first one. Return an empty string if there are no letters.
```

Folder: `tasks/08_longest_word/`
### 09. Word frequency table

```text
Write a global Lua function `freq_table(text)` that takes a string and returns a table mapping each lowercase word (a run of letters) to the number of times it appears. Treat words case-insensitively.
```

Folder: `tasks/09_freq_table/`
### 10. Parse key=value pairs

```text
Write a global Lua function `parse_kv(s)` that takes a comma-separated string of key=value pairs and returns a table mapping each key to its value (both strings). Ignore whitespace around keys, values and commas.
```

Folder: `tasks/10_parse_kv/`
### 11. Caesar cipher shift

```text
Write a global Lua function `caesar(s, shift)` that returns a new string where each letter in s is shifted by `shift` positions in the alphabet (wrapping around, keeping case). Non-letters stay unchanged. `shift` may be any integer.
```

Folder: `tasks/11_caesar/`
### 12. Join with separator

```text
Write a global Lua function `join(arr, sep)` that returns the strings of the array `arr` joined with the separator string `sep` (an empty array gives an empty string).
```

Folder: `tasks/12_join_strings/`

## Arrays
### 13. Sum of numbers

```text
Write a global Lua function `sum_array(arr)` that takes an array of numbers and returns the sum of all elements (0 for an empty array).
```

Folder: `tasks/13_sum_array/`
### 14. Maximum value

```text
Write a global Lua function `max_in_array(arr)` that takes an array of numbers and returns the maximum value, or nil if the array is empty.
```

Folder: `tasks/14_max_in_array/`
### 15. Keep even numbers

```text
Write a global Lua function `filter_evens(arr)` that returns a new array containing only the even numbers from the input array, preserving order.
```

Folder: `tasks/15_filter_evens/`
### 16. Double each element

```text
Write a global Lua function `map_double(arr)` that returns a new array where each element is twice the corresponding element of the input array.
```

Folder: `tasks/16_map_double/`
### 17. Unique preserving order

```text
Write a global Lua function `remove_duplicates(arr)` that returns a new array containing the first occurrence of each value from the input array, keeping the original order.
```

Folder: `tasks/17_remove_duplicates/`
### 18. Flatten one level

```text
Write a global Lua function `flatten_one_level(arr)` that takes an array whose elements may be numbers or arrays of numbers, and returns a new array with the inner arrays spliced in, one level only (deeper nesting is left as is).
```

Folder: `tasks/18_flatten_one_level/`
### 19. Sort numbers descending

```text
Write a global Lua function `sort_desc(nums)` that takes a table `nums` of numbers and returns a new table with the numbers sorted in descending order.
```

Folder: `tasks/19_sort_desc_numbers/`
### 20. Sort strings by length

```text
Write a global Lua function `sort_by_len(strs)` that takes a table of strings and returns a new table with the strings sorted by increasing length. If two strings have the same length, keep their original order.
```

Folder: `tasks/20_sort_by_length/`
### 21. Binary search in sorted array

```text
Write a global Lua function `binary_search(arr, target)` that receives a sorted table `arr` of numbers and a number `target`. Return the 1-based index of `target` if it is present, or nil otherwise. Use binary search.
```

Folder: `tasks/21_binary_search/`
### 22. Stack push and pop

```text
Write two global Lua functions `stack_push(stack, v)` and `stack_pop(stack)`. `stack_push` inserts value `v` at the top of the table `stack`. `stack_pop` removes and returns the top element, or returns nil if the stack is empty.
```

Folder: `tasks/22_stack_push_pop/`
### 23. Balanced parentheses checker

```text
Write a global Lua function `is_balanced(s)` that returns true if the string `s` contains properly balanced parentheses `(` and `)`, and false otherwise.
```

Folder: `tasks/23_balanced_parentheses/`

## Math and loops
### 24. Nth Fibonacci number

```text
Write a global Lua function `fibonacci(n)` that returns the nth Fibonacci number, using fibonacci(0) = 0 and fibonacci(1) = 1.
```

Folder: `tasks/24_fibonacci_nth/`
### 25. Greatest common divisor

```text
Write a global Lua function `gcd(a, b)` that returns the greatest common divisor of two integers.
```

Folder: `tasks/25_gcd_integers/`
### 26. Prime check

```text
Write a global Lua function `is_prime(n)` that returns true when n is a prime number and false otherwise.
```

Folder: `tasks/26_is_prime_number/`
### 27. Factorial

```text
Write a global Lua function `factorial(n)` that returns the factorial of a nonnegative integer n.
```

Folder: `tasks/27_factorial_number/`
### 28. Clamp value to range

```text
Write a global Lua function `clamp(x, lo, hi)` that returns x limited to the inclusive range from lo to hi.
```

Folder: `tasks/28_clamp_value/`
### 29. Round to n decimals

```text
Write a global Lua function `round_to_n_decimals(x, n)` that returns x rounded to n decimal places.
```

Folder: `tasks/29_round_to_n_decimals/`
### 30. FizzBuzz table

```text
Write a global Lua function `fizzbuzz(n)` that returns an array of n strings: "FizzBuzz" for multiples of 15, "Fizz" for multiples of 3, "Buzz" for multiples of 5, otherwise the number as a string.
```

Folder: `tasks/30_fizzbuzz/`
### 31. Countdown array

```text
Write a global Lua function `countdown(n)` that returns an array counting down from n to 1. For n less than 1 return an empty array.
```

Folder: `tasks/31_countdown/`
### 32. Collatz step count

```text
Write a global Lua function `collatz_steps(n)` for a positive integer n: repeat "if even, divide by 2, otherwise multiply by 3 and add 1" until the value is 1, and return how many steps that took (collatz_steps(1) is 0).
```

Folder: `tasks/32_collatz_steps/`
### 33. Sum of digits

```text
Write a global Lua function `sum_of_digits(n)` that returns the sum of the decimal digits of a non-negative integer n.
```

Folder: `tasks/33_sum_of_digits/`
### 34. Count by k

```text
Write a global Lua function `count_by(n, k)` that returns an array of the numbers k, 2k, 3k, ... up to and including n (only multiples of k that are at most n). Assume k is a positive integer.
```

Folder: `tasks/34_count_by/`
### 35. Multiplication table row

```text
Write a global Lua function `mult_row(n, upto)` that returns an array {n*1, n*2, ..., n*upto}.
```

Folder: `tasks/35_mult_row/`
